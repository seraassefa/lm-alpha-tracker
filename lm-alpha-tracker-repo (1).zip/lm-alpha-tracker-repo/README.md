# LM Alpha Cohort — Program Tracker

Auto-syncing program tracker for the Lockheed Martin Alpha Cohort Executive Leadership Coaching engagement. Pulls live data from Notion (to-dos and milestones) and Airtable (RSVP statuses) every night and publishes an updated HTML page to Netlify.

---

## How it works

1. A **Netlify Scheduled Function** (`nightly-sync.js`) runs every night at 11pm PT
2. It queries the **Notion tracker database** and the **Airtable RSVP base**
3. It injects that data into `template.html` and writes the result to `public/index.html`
4. Netlify serves `public/index.html` as the live site — the URL never changes

---

## One-time setup

### 1. Clone this repo and push to GitHub

```bash
git clone <this-repo-url>
cd lm-alpha-tracker
git remote set-url origin <your-github-repo-url>
git push -u origin main
```

### 2. Connect to Netlify

1. Go to [app.netlify.com](https://app.netlify.com) → **Add new site** → **Import an existing project**
2. Choose **GitHub** and select this repo
3. Build settings:
   - **Build command:** *(leave blank)*
   - **Publish directory:** `public`
4. Click **Deploy site**

### 3. Add environment variables

In Netlify: **Site settings → Environment variables → Add variable**

| Variable | Value | Where to get it |
|---|---|---|
| `NOTION_API_KEY` | `secret_xxx...` | [notion.so/my-integrations](https://notion.so/my-integrations) |
| `NOTION_DATABASE_ID` | `48b5f939-4b9d-43d5-a328-d31e1c2de4eb` | Pre-filled — your LM tracker DB |
| `AIRTABLE_API_KEY` | `patXXX...` | [airtable.com/create/tokens](https://airtable.com/create/tokens) |
| `AIRTABLE_BASE_ID` | `appdW3ysH5cEfz62d` | Pre-filled — your RSVP base |
| `AIRTABLE_TABLE_ID` | `tbl9duFuL6cZ0bOca` | Pre-filled |
| `AIRTABLE_VIEW_ID` | `viwM1vamzZcx7XsfB` | Pre-filled |
| `SYNC_SECRET` | *(any random string)* | Used to protect the manual trigger |

### 4. Create the Notion integration

1. Go to [notion.so/my-integrations](https://notion.so/my-integrations) → **New integration**
2. Name it `LM Alpha Tracker Sync`, set workspace to your Trium workspace
3. Copy the **Internal Integration Secret** → set as `NOTION_API_KEY`
4. Open the LM Alpha tracker database in Notion → **...** menu → **Add connections** → select your integration

### 5. Create the Airtable token

1. Go to [airtable.com/create/tokens](https://airtable.com/create/tokens) → **Create token**
2. Scopes needed: `data.records:read`
3. Add access to the **LM Alpha RSVP** base
4. Copy the token → set as `AIRTABLE_API_KEY`

### 6. Trigger a manual sync to test

Once env vars are set, visit:
```
https://your-site.netlify.app/.netlify/functions/manual-sync?token=YOUR_SYNC_SECRET
```

You should see `Sync complete` and the live site will update within seconds.

---

## Scheduled sync

The cron runs at `0 6 * * *` (6am UTC = 11pm PT). To change the schedule, edit the `config.schedule` export in `netlify/functions/nightly-sync.js`.

---

## Repo structure

```
├── netlify/
│   └── functions/
│       ├── nightly-sync.js   ← Scheduled function (Notion + Airtable → HTML)
│       └── manual-sync.js    ← On-demand trigger for testing
├── public/
│   └── index.html            ← Generated at sync time (committed by function)
├── template.html             ← Base HTML with __SYNC_DATE__, __NOTION_DATA__,
│                                and __AIRTABLE_DATA__ placeholders
├── netlify.toml              ← Netlify build + function config
├── package.json
├── .env.example              ← Copy to .env for local dev
└── README.md
```

---

## Local development

```bash
npm install
cp .env.example .env
# Fill in your actual keys in .env

# Run the sync locally to test:
node -e "import('./netlify/functions/nightly-sync.js').then(m => m.default())"

# Or use Netlify Dev:
npm install -g netlify-cli
netlify dev
```

---

## Updating the tracker design

To change the tracker's layout or content:
1. Edit `template.html` — it's the full tracker HTML with three placeholder tokens
2. Do **not** replace `__SYNC_DATE__`, `__NOTION_DATA__`, or `__AIRTABLE_DATA__` — the sync function needs those
3. Commit and push — Netlify will redeploy automatically
